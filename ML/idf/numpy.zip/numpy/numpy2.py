# -*- coding: utf-8 -*-



import numpy as np
from pylab import *

a = np.array([1, 4, 5, 8], float)
b = np.array([1, 2, 3, 4], float)

c=np.add(a,b)

print(c)


