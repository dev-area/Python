#!/usr/local/bin/python

# What is wrong with this?

cheese = ['Cheddar', 'Stilton', 'Cornish Yarg']
cheese += 'Oke'
cheese.append('Oke')
print (cheese)
